export class user{
    constructor(){}
        public name: string;
        public id: string;
        public mobile: number;
        public email: string;


    }
