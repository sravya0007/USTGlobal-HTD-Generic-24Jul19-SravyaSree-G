import {Component } from "@angular/core";

@Component({
    selector : 'app-p' ,// codong standard -use app- before any selector,<spec.ts is for tsting purpose>
    template : `<h1>p component is working</h1>`,
    styles : [`h1{background: cyan; color: black}`]

})
export class PComponent {

}