import {Component } from "@angular/core";

@Component({
    selector : 'app-sample' ,// codong standard -use app- before any selector,<spec.ts is for tsting purpose>
    templateUrl : './sample.component.html',
    styleUrls : ['./sample.component.css']
})
export class SampleComponent {

}