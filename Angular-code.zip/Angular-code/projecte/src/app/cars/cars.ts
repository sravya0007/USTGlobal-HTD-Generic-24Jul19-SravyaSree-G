// tslint:disable-next-line: class-name
export class cars {
    constructor() {}
        public brand: string;
        public model: string;
        public yor: number;
        public email: string;


    }
