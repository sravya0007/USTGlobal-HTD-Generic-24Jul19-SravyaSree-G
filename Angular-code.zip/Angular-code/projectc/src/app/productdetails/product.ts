// tslint:disable-next-line: class-name
export class product {
    constructor() {}
        public name: string;
        public image: null;
        
        public desc: string;


    }
