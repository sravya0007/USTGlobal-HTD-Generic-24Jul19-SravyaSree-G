import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddtaskComponent } from './addtask/addtask.component';
import{RouterModule} from '@angular/router';
import{ViewtasksComponent} from './viewtasks/viewtasks.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';

@NgModule({
  declarations: [
    AppComponent,
    AddtaskComponent,
    HomeComponent,
    HeaderComponent,
    ViewtasksComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forRoot([
      {path:'header',component:HeaderComponent},
      {path:'home',component:HomeComponent},
      {path:'addtask',component:AddtaskComponent},
      {path:'view',component:ViewtasksComponent}
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
