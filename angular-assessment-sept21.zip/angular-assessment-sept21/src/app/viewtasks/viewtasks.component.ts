import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewtasks',
  templateUrl: './viewtasks.component.html',
  styleUrls: ['./viewtasks.component.css']
})
export class ViewtasksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
