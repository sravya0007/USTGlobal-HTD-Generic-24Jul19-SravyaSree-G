import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cars',
  templateUrl: './cars.component.html',
  styleUrls: ['./cars.component.css']
})
export class CarsComponent implements OnInit {

  constructor() { }
  car: any []=[];
  cars:any[]=[
    {
      name:'buggati',
      image:'https://cdn.pixabay.com/photo/2019/07/07/14/03/fiat-4322521__340.jpg',
      description:'Cars came into global use during the 20th century, and developed economies depend on them. The year 1886 is regarded as the birth year of the modern car when German inventor Karl Benz patented his Benz Patent-Motorwagen. Cars became widely available in the early 20th century. One of the first cars accessible to the masses was the 1908 Model T, an American car manufactured by the Ford Motor Company'

    } ,{
      name:'ferrari',
      image:'https://cdn.pixabay.com/photo/2016/04/01/12/16/car-1300629__340.png',
      description:'Cars came into global use during the 20th century, and developed economies depend on them. The year 1886 is regarded as the birth year of the modern car when German inventor Karl Benz patented his Benz Patent-Motorwagen. Cars became widely available in the early 20th century. One of the first cars accessible to the masses was the 1908 Model T, an American car manufactured by the Ford Motor Company'

    },
    {
      name:'URUS',
      image:'https://cdn.pixabay.com/photo/2017/09/01/20/23/ford-2705402__340.jpg',
      description:'Cars came into global use during the 20th century, and developed economies depend on them. The year 1886 is regarded as the birth year of the modern car when German inventor Karl Benz patented his Benz Patent-Motorwagen. Cars became widely available in the early 20th century. One of the first cars accessible to the masses was the 1908 Model T, an American car manufactured by the Ford Motor Company'

    },
    {
      name:'buggati',
      image:'https://cdn.pixabay.com/photo/2019/07/07/14/03/fiat-4322521__340.jpg',
      description:'Cars came into global use during the 20th century, and developed economies depend on them. The year 1886 is regarded as the birth year of the modern car when German inventor Karl Benz patented his Benz Patent-Motorwagen. Cars became widely available in the early 20th century. One of the first cars accessible to the masses was the 1908 Model T, an American car manufactured by the Ford Motor Company'

    } ,{
      name:'ferrari',
      image:'https://cdn.pixabay.com/photo/2016/04/01/12/16/car-1300629__340.png',
      description:'Cars came into global use during the 20th century, and developed economies depend on them. The year 1886 is regarded as the birth year of the modern car when German inventor Karl Benz patented his Benz Patent-Motorwagen. Cars became widely available in the early 20th century. One of the first cars accessible to the masses was the 1908 Model T, an American car manufactured by the Ford Motor Company'

    },
    {
      name:'URUS',
      image:'https://cdn.pixabay.com/photo/2017/09/01/20/23/ford-2705402__340.jpg',
      description:'Cars came into global use during the 20th century, and developed economies depend on them. The year 1886 is regarded as the birth year of the modern car when German inventor Karl Benz patented his Benz Patent-Motorwagen. Cars became widely available in the early 20th century. One of the first cars accessible to the masses was the 1908 Model T, an American car manufactured by the Ford Motor Company'

    },
    {
      name:'silverstone',
      image:'https://cdn.pixabay.com/photo/2014/09/07/22/34/car-race-438467__340.jpg',
      description:'Cars came into global use during the 20th century, and developed economies depend on them. The year 1886 is regarded as the birth year of the modern car when German inventor Karl Benz patented his Benz Patent-Motorwagen. Cars became widely available in the early 20th century. One of the first cars accessible to the masses was the 1908 Model T, an American car manufactured by the Ford Motor Company'

    }
  ];

  ngOnInit() {
  }
send(car){
  this.car=car;
}
}
